<?php
/**
 * 配置文件
 */
return array(
    'DB_TYPE' => 'mysql',
    'DB_HOST' => 'localhost',
    'DB_NAME' => 'suce',
    'DB_USER' => 'root',
    'DB_PWD' => 'Chen8816',
    'DB_PORT' => '3306',
    'DB_PREFIX' => 'sc_',
    //密钥
    "AUTHCODE" => 'wyjsSFQP5sTLhTMsnN',
    //cookies
    "COOKIE_PREFIX" => 'zgiH0n_',
);
