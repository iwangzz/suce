<?php
return array(
    "NAME" => "广告名称",
    "HOW_TO_USE" => '调用代码',
    "AD_CONTENT" => "广告代码"
);